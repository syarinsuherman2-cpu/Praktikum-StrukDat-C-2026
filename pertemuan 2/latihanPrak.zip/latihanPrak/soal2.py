thistuple = ("B001", "Laptop Gaming", 15000000)
print(thistuple)

x = ("B001", "Laptop Gaming", 15000000)
y = list(x)
y [2] = "14000000"
x = tuple(y)

print(x)

thistuple = ("B001", "Laptop Gaming", 15000000)
(kode, nama, harga) = thistuple

print(kode)
print(nama)
print(harga)


