thislist = ["15", "50", "30", "25", "40"]
thislist.sort() 
print(thislist)

thislist = ["15", "50", "30", "25", "40"]
thislist.insert(-2, "75")
print(thislist)

thislist = ["15", "50", "30", "25", "40"]
for i in range(len(thislist)):
    print(thislist[i])

thislist = ['15', '50', '30', '25', '40']
thislist.append('100')
print(thislist)



