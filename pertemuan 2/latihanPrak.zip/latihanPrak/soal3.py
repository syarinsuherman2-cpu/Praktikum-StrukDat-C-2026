soal4.py
