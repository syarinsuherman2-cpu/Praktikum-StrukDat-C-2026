def registrasi_gadget(merk, tipe, harga, sn):
    if harga < 1000000:
        print("harga tidak valid")
        return None
    if len(sn) < 5:
        print("serial number tidak valid")
        return None
    return {
    "merk": "laptop",
    "tipe":"hp",
    "harga": 1500000,
    "sn": 12345 
}

inventaris = []

print(registrasi_gadget)

for i in range(3):
    merk = input("masukkan merk gadget: ")
    tipe = input("masukkan tipe gadget: ")
    harga = int(input("masukkan harga gadget: "))
    sn = input("masukkan serial number gadget: ")
    gadget = registrasi_gadget(merk, tipe, harga, sn)
    
    if gadget:
        inventaris 
registrasi_gadget ={
    merk{merk}, tipe{tipe}, harga{harga}, sn{sn}
}



