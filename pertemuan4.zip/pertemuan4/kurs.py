# kurs.py
data_kurs = {
    "USD": 16875,
    "EUR": 19995,
    "SGD": 13360,
    "JPY": 109
}